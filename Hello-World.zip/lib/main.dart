import 'package:flutter/material.dart';

void main() {
  runApp(
    MyApp(),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.blue,
        body: SafeArea(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            CircleAvatar(
              radius: 50,
            ),
            Text(
              'Aditi',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 40.0,
                fontFamily: 'Pacifico',
                color: Colors.white,
              ),
            ),
            Text(
              'Flutter Developer',
              style: TextStyle(
                fontSize: 20.0,
                fontFamily: 'Source Sans Pro',
                color: Colors.black,
                fontWeight: FontWeight.bold,
              ),
            ),
            Card(
              margin: EdgeInsets.all(20.0),
              color: Colors.white,
              child: ListTile(
                  leading: Icon(
                    Icons.phone,
                    color: Colors.black,
                    size: 20.0,
                  ),
                  title: Text(
                    '+91 8412937281',
                    style: TextStyle(
                      fontFamily: 'Pacifico',
                      fontSize: 20.0,
                      color: Colors.black54,
                    ),
                  )),
            ),
            Card(
              margin: EdgeInsets.all(20.0),
              color: Colors.white,
              child: ListTile(
                  leading: Icon(
                    Icons.email,
                    color: Colors.black,
                    size: 20.0,
                  ),
                  title: Text(
                    'aryanmali438@gmail.com',
                    style: TextStyle(
                      fontFamily: 'Pacifico',
                      fontSize: 20.0,
                      color: Colors.black54,
                    ),
                  )),
            )
          ],
        )),
      ),
    );
  }
}
