function getBotResponse(input) {
   

    // Simple responses
    if (input == "who is founder of sciAstra?") {
        return " Vivek Dwivedi and Akhil Tripathi";
    } else if (input == "where is the headquarters of sciAstra?") {
        return "Bhubaneswar, Odisha";
    }
    else if (input == "what is sciastra?") {
        return "we guide students who want to become scientists and pursue research by helping them secure admissions in the top colleges for the same like IISER, NISER, CEBS, ICAR, CMI, etc. Our mentors are from the top research institutes like IISER, NISER, IACS, CMI, ISI, IISC Bangalore, and so on";
    }
    else if (input == "list of  courses provided by sciastra") {
        return "IISC,IISER,NISER,ISI,CMI,IACS,CEBS";
    }
    else if (input == "list of exams.") {
        return "IAT,NEST,ISI/CMI,UPST";
    }
    else if (input == "what is the criteria for IAT exam?") {
        return " a candidate must have taken at least three subjects among Biology, Chemistry, Mathematics and Physics during their class 12th exam. Candidates belonging to SC/ST/PwD should have scored a minimum of 55% marks in their class 12th exam.";
    }
    else if (input == "what is exam pattern for IISER exam?") {
        return "The IISER exam pattern 2024 has IISER Admission Test has Multiple Choice Questions (MCQ). The medium of language in the entrance exam is English and Hindi.";
    }
    else if (input == "how much time required crack iiser exam?") {
        return "10 months of time is pretty sufficient. If you are preparing for the IIT-JEE or NEET then no need to prepare for IAT separately. Just when one month would be left for IISER aptitude test then download the question papers of previous years and give mock test with full attention in 3 hrs.";
    }
    else if (input == "What are the target students of Sciastra?") {
        return "we guide students who want to become scientists and pursue research by helping them secure admissions in the top colleges for the same like IISER, NISER, CEBS, ICAR, CMI";
    }
    else if (input == "Why should one choose CEBS?") {
        return "Are you a JEE or NEET student who is passionate about pursuing a career in basic sciences, you might be wondering which institute to choose for your undergraduate education. There are many options available, but one of them stands out for its excellence, diversity, and opportunities: CEBS. Centre for Excellence in Basic Sciences is a premier institution that offers high-quality education and research opportunities in various fields of science. In this blog post, we will tell you why CEBS is a great choice for you and how you can get admission there.";
    } else {
        return "Try asking something else!";
    }
}